package com.baeldung.namingstrategy;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaNamingConventionApplication {
}
