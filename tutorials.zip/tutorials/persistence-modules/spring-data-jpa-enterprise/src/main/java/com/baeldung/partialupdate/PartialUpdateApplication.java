package com.baeldung.partialupdate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 
public class PartialUpdateApplication {

    public static void main(String[] args) {
        SpringApplication.run(PartialUpdateApplication.class, args);
    }
}
