package com.baeldung.boot.services;

import com.baeldung.boot.domain.Bar;

public interface IBarService extends IOperations<Bar> {
    //
}
