package com.baeldung.elementcollection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElementCollectionApplication {
    public static void main(String[] args) {
        SpringApplication.run(ElementCollectionApplication.class, args);
    }
}
